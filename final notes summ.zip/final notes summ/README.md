# NeuroNotes AI — Smart Notes Summarizer

An AI-powered study assistant. Upload a PDF or TXT file (or paste notes) and get:

- a **smart summary** (short / medium / detailed, bullet points / paragraph / exam revision notes, English or Hindi)
- **key concepts, takeaways and highlighted keywords**
- **multiple-choice quizzes** with explanations and a final score
- **flashcards** with 3D flip animation
- **"Ask your notes"** chat that answers only from your material

Built with **HTML, CSS, vanilla JavaScript, Python Flask, PyPDF and a free AI API (Groq, OpenRouter, Gemini or local Ollama)**.
No database, no login, no frameworks — easy to read and explain.

---

## Project structure

```text
neuronotes-ai/
├── app.py                  # Flask backend: routes, PDF extraction, Gemini calls
├── requirements.txt        # Python packages
├── .env.example            # Template for your secret settings
├── templates/
│   └── index.html          # The page
├── static/
│   ├── css/style.css       # All styling and animations
│   ├── js/script.js        # Frontend logic (uploads, API calls, quiz, chat…)
│   └── assets/favicon.svg
└── README.md
```

---

## Setup on Windows

### 1. Install Python
Download Python 3.10 or newer from <https://www.python.org/downloads/>.
During installation tick **"Add python.exe to PATH"**.
Check it worked — open **Command Prompt** and run:

```bat
python --version
```

### 2. Open the project folder

```bat
cd path\to\neuronotes-ai
```

### 3. Create a virtual environment and install packages

```bat
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

(You should now see `(venv)` at the start of the prompt.)

PowerShell users: if activation is blocked, run
`Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` first, then `venv\Scripts\Activate.ps1`.

### 4. Choose a free AI provider and get a key
The app works with four providers. Pick **one** (Groq is the easiest if Gemini's limit is used up):

| Provider | Cost | Get a key | `.env` setting |
|----------|------|-----------|----------------|
| **Groq** | free tier, fast | <https://console.groq.com/keys> | `LLM_PROVIDER=groq` + `GROQ_API_KEY=...` |
| **OpenRouter** | has free `:free` models | <https://openrouter.ai/keys> | `LLM_PROVIDER=openrouter` + `OPENROUTER_API_KEY=...` |
| **Gemini** | free tier with limits | <https://aistudio.google.com/apikey> | `LLM_PROVIDER=gemini` + `GEMINI_API_KEY=...` |
| **Ollama** | 100% free, runs on your PC, no key, no limits | install from <https://ollama.com>, then run `ollama pull llama3.2` | `LLM_PROVIDER=ollama` |

Free tiers and model names change over time. If you get a "model isn't available" message, set `LLM_MODEL=` to a model your account lists. Ollama is slower (it uses your own computer) but never runs out.

### 5. Add your settings
Copy the example settings file and edit it:

```bat
copy .env.example .env
notepad .env
```

Set `LLM_PROVIDER` and the matching key, save, and close Notepad. Example for Groq:

```text
LLM_PROVIDER=groq
GROQ_API_KEY=gsk_...your-key...
```

> Never share the `.env` file or upload it to GitHub. The key stays on the server and is never sent to the browser.
> Restart `python app.py` after every change to `.env`.

### 6. Run the app

```bat
python app.py
```

Open <http://127.0.0.1:5000> in your browser. Press `Ctrl + C` in the terminal to stop.

---

## Demo mode (no API key)

If no key is set, a yellow banner appears in the workspace with a **Demo mode** switch.
Demo mode returns **pre-written sample output about the built-in "photosynthesis" sample document**.
It is clearly labelled *DEMO* and is **not** generated from your notes — it exists only so you can preview the interface. Real features need the API key.

---

## How it works

| Step | What happens |
|------|--------------|
| Upload | `POST /api/extract` validates the file type and size, checks PDFs really start with `%PDF-`, reads text with **PyPDF** from a temporary file (deleted right after), and returns it. |
| Summarize | `POST /api/summarize` sends the notes plus your options to the AI model and asks for structured JSON (title, summary, key concepts, takeaways, keywords). |
| Quiz / Flashcards | `POST /api/mcqs` and `POST /api/flashcards` ask Gemini for JSON built only from your notes; the backend validates the structure. |
| Chat | `POST /api/ask` sends your question and the notes; Gemini must answer only from the notes and flag when they don't cover it. |

### Limits (and why)
- Files up to **10 MB**; `.pdf` and `.txt` only.
- Notes up to **60,000 characters** (roughly 30–40 pages). Longer text is rejected (or trimmed on upload) with a clear message.
- Scanned/image-only PDFs have no text layer and can't be read — paste the text instead.

### Long documents (chunking)
`chunk_text()` in `app.py` is already used: above 30,000 characters, the summary is built in two passes — each ~15,000-character chunk is condensed first, then the condensed notes are summarized. To raise the 60,000-character limit later, increase `MAX_CHARS` (quizzes, flashcards and chat currently send the full text in one request).

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `python` not recognised | Reinstall Python with "Add to PATH" ticked, or use `py` instead of `python`. |
| Banner says no API key | Make sure the file is named `.env` (not `.env.txt`), `LLM_PROVIDER` matches the key you filled in, and restart `python app.py`. |
| "AI service rejected the request" | The key is invalid or restricted. Create a new key. |
| "AI rate limit reached" | Free tiers have minute/daily limits. Wait, or switch `LLM_PROVIDER` to another free option (or Ollama for no limits). |
| "No readable text was found" | The PDF is probably scanned images. Paste the text instead. |
| Icons missing | The page loads Lucide icons and fonts from a CDN — check your internet connection. |

---

## Customizing
- Change colours in the `:root` block at the top of `static/css/style.css`.
- Change the AI model with `LLM_MODEL` in `.env`.
- Prompts live in the `build_*` functions in `app.py`.
