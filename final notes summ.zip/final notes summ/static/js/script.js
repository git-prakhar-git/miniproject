/* =========================================================================
   NeuroNotes AI — script.js (vanilla JavaScript)
   1 Helpers · 2 UI chrome (theme, nav, reveal, particles) · 3 Server status
   4 Upload · 5 Summary · 6 MCQs · 7 Flashcards · 8 Chat
   ========================================================================= */
(() => {
  "use strict";

  /* ---------- 1. Helpers ---------- */
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const icons = () => { if (window.lucide) window.lucide.createIcons(); };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const state = {
    configured: false,     // does the server have a Gemini key?
    maxChars: 60000,
    maxMb: 10,
    fromFile: false,       // is the textarea content from an uploaded file?
    summary: null,
    mcqs: [], mcqAnswered: 0, mcqScore: 0,
    cards: [], cardIdx: 0,
    chat: [],
  };
  const locks = new Set(); // prevents double submissions per feature

  const SAMPLE_TEXT = `How Photosynthesis Works

Photosynthesis is the process by which green plants, algae and some bacteria convert light energy into chemical energy stored in glucose. It takes place mainly in the leaves, inside organelles called chloroplasts. Chloroplasts contain chlorophyll, the green pigment that absorbs light, mostly in the red and blue parts of the spectrum.

The overall equation is: 6CO2 + 6H2O + light energy -> C6H12O6 + 6O2. Carbon dioxide enters the leaf through small pores called stomata, while water is absorbed by the roots and carried up through the xylem.

Photosynthesis has two linked stages. The light-dependent reactions occur in the thylakoid membranes. Light energy splits water molecules (photolysis), releasing oxygen as a by-product and producing the energy carriers ATP and NADPH. The light-independent reactions, known as the Calvin cycle, occur in the stroma. Here the enzyme RuBisCO fixes carbon dioxide, and ATP and NADPH are used to build glucose.

The rate of photosynthesis is limited by light intensity, carbon dioxide concentration and temperature. If any one of these is in short supply it becomes the limiting factor. Very high temperatures denature enzymes and slow the process down.

Photosynthesis is essential for life on Earth: it forms the base of almost every food chain and produces the oxygen in our atmosphere.`;

  /* Toast notifications */
  function toast(message, type = "info") {
    const icon = type === "success" ? "check-circle" : type === "error" ? "alert-circle" : "info";
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.innerHTML = `<i data-lucide="${icon}"></i><span>${esc(message)}</span>`;
    $("#toasts").appendChild(el);
    icons();
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 300); }, type === "error" ? 5000 : 2800);
  }

  /* JSON POST helper that turns server/network problems into readable Errors */
  async function postJSON(url, body) {
    let res;
    try {
      res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    } catch (e) {
      throw new Error("Couldn't reach the server. Make sure the Flask app is still running.");
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* non-JSON response */ }
    if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status}). Please try again.`);
    return data;
  }

  /* Shared request fields */
  const useDemo = () => !state.configured && $("#demoToggle").checked;
  const getOption = (name) => ($(`input[name="${name}"]:checked`) || {}).value;
  const notesText = () => $("#notesInput").value.trim();

  /* Check the notes before calling the API. Returns an error message or "" */
  function validateNotes() {
    const t = notesText();
    if (!t) return "Please upload a file or paste some notes first.";
    if (t.length < 50) return "Your notes are very short. Please add at least 50 characters.";
    if (t.length > state.maxChars) return `Your notes are too long (${t.length.toLocaleString()} characters). The limit is ${state.maxChars.toLocaleString()}. Please trim them.`;
    if (!state.configured && !useDemo()) return "No API key is configured. Add GEMINI_API_KEY to your .env file, or switch on Demo mode.";
    return "";
  }

  /* ---------- 2. UI chrome ---------- */
  // Theme (dark by default)
  const root = document.documentElement;
  function applyTheme(theme) {
    root.setAttribute("data-theme", theme);
    const btn = $("#themeToggle");
    btn.innerHTML = `<i data-lucide="${theme === "dark" ? "sun" : "moon"}"></i>`;
    btn.setAttribute("aria-label", theme === "dark" ? "Switch to light theme" : "Switch to dark theme");
    icons();
  }
  let savedTheme = "dark";
  try { savedTheme = localStorage.getItem("nn-theme") || "dark"; } catch (e) { /* storage blocked */ }
  applyTheme(savedTheme);
  $("#themeToggle").addEventListener("click", () => {
    const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    applyTheme(next);
    try { localStorage.setItem("nn-theme", next); } catch (e) { /* ignore */ }
  });

  // Mobile navigation
  const menuBtn = $("#menuBtn"), navLinks = $("#navLinks");
  function setMenu(open) {
    navLinks.classList.toggle("open", open);
    menuBtn.setAttribute("aria-expanded", String(open));
    menuBtn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    menuBtn.innerHTML = `<i data-lucide="${open ? "x" : "menu"}"></i>`;
    icons();
  }
  menuBtn.addEventListener("click", () => setMenu(!navLinks.classList.contains("open")));
  $$("a", navLinks).forEach((a) => a.addEventListener("click", () => setMenu(false)));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") setMenu(false); });

  // Scroll-reveal
  const revealEls = $$(".reveal");
  if ("IntersectionObserver" in window && !reduceMotion) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    revealEls.forEach((el) => io.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add("in"));
  }

  // Particles (small, subtle, paused when tab hidden)
  (function particles() {
    const canvas = $("#particles");
    if (!canvas || reduceMotion) return;
    const ctx = canvas.getContext("2d");
    let w = 0, h = 0, dots = [], raf = null;
    const colors = ["139,92,246", "34,211,238", "217,70,239"];
    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(70, (w * h) / 22000));
      dots = Array.from({ length: count }, () => ({
        x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.6 + .4,
        vx: (Math.random() - .5) * .18, vy: -(Math.random() * .25 + .05),
        c: colors[Math.floor(Math.random() * colors.length)], a: Math.random() * .5 + .2,
      }));
    }
    function tick() {
      ctx.clearRect(0, 0, w, h);
      for (const d of dots) {
        d.x += d.vx; d.y += d.vy;
        if (d.y < -4) { d.y = h + 4; d.x = Math.random() * w; }
        if (d.x < -4) d.x = w + 4; if (d.x > w + 4) d.x = -4;
        ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${d.c},${d.a})`; ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    }
    resize(); tick();
    window.addEventListener("resize", resize);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) { cancelAnimationFrame(raf); raf = null; } else if (!raf) tick();
    });
  })();

  /* ---------- 3. Server status ---------- */
  async function loadStatus() {
    const banner = $("#apiBanner");
    try {
      const res = await fetch("/api/status");
      const s = await res.json();
      state.configured = !!s.configured;
      state.maxChars = s.max_chars || state.maxChars;
      state.maxMb = s.max_upload_mb || state.maxMb;
      $("#limitText").textContent = state.maxChars.toLocaleString();
      $("#dzHint").textContent = `Max ${state.maxMb} MB · .pdf, .txt`;
      banner.hidden = state.configured;
    } catch (e) {
      banner.hidden = false;
      banner.classList.add("error");
      $(".banner-text", banner).innerHTML = "<strong>Can't reach the server</strong><span>Start the Flask app with <code>python app.py</code> and reload this page.</span>";
      $(".switch", banner).hidden = true;
      icons();
    }
    updateCount();
  }

  /* ---------- 4. Upload & notes input ---------- */
  const notes = $("#notesInput");
  const dropzone = $("#dropzone"), fileInput = $("#fileInput"), fileCard = $("#fileCard");
  let currentXhr = null;

  function updateCount() {
    const n = notes.value.length;
    const el = $("#charCount");
    el.textContent = `${n.toLocaleString()} / ${state.maxChars.toLocaleString()} characters`;
    el.classList.toggle("over", n > state.maxChars);
  }
  notes.addEventListener("input", updateCount);

  const fmtSize = (b) => (b < 1024 ? `${b} B` : b < 1048576 ? `${(b / 1024).toFixed(1)} KB` : `${(b / 1048576).toFixed(2)} MB`);

  function validateFile(file) {
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (!["pdf", "txt"].includes(ext)) return "Unsupported file type. Please choose a .pdf or .txt file.";
    if (file.size === 0) return "That file is empty.";
    if (file.size > state.maxMb * 1048576) return `That file is too large (${fmtSize(file.size)}). The limit is ${state.maxMb} MB.`;
    return "";
  }

  function setProgress(pct, label) {
    $("#fileProgress").style.width = `${pct}%`;
    $("#fileProgressWrap").setAttribute("aria-valuenow", String(Math.round(pct)));
    if (label) $("#fileStatus").textContent = label;
  }

  function resetFileUI() {
    if (currentXhr) { currentXhr.abort(); currentXhr = null; }
    fileCard.hidden = true;
    dropzone.hidden = false;
    fileInput.value = "";
  }

  function handleFile(file) {
    const problem = validateFile(file);
    if (problem) { toast(problem, "error"); return; }
    if (currentXhr) currentXhr.abort();

    const ext = file.name.split(".").pop().toUpperCase();
    $("#fileName").textContent = file.name;
    $("#fileMeta").textContent = `${ext} file · ${fmtSize(file.size)}`;
    dropzone.hidden = true; fileCard.hidden = false;
    setProgress(0, "Uploading…");
    icons();

    const form = new FormData();
    form.append("file", file);
    const xhr = new XMLHttpRequest();
    currentXhr = xhr;
    xhr.open("POST", "/api/extract");
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) setProgress((e.loaded / e.total) * 85, "Uploading…"); };
    xhr.upload.onload = () => setProgress(88, "Extracting text…");
    xhr.onload = () => {
      currentXhr = null;
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch (e) { /* ignore */ }
      if (xhr.status === 200) {
        notes.value = data.text;
        state.fromFile = true;
        updateCount();
        setProgress(100, `Ready · ${data.characters.toLocaleString()} characters${data.pages ? ` · ${data.pages} page${data.pages > 1 ? "s" : ""}` : ""}`);
        if (data.truncated) toast(`Your file is long, so only the first ${data.limit.toLocaleString()} characters were kept.`, "info");
        else toast("File loaded. Ready to summarize.", "success");
      } else {
        resetFileUI();
        toast(data.error || "We couldn't process that file.", "error");
      }
    };
    xhr.onerror = () => { currentXhr = null; resetFileUI(); toast("Upload failed. Make sure the server is running.", "error"); };
    xhr.send(form);
  }

  $("#browseBtn").addEventListener("click", (e) => { e.stopPropagation(); fileInput.click(); });
  dropzone.addEventListener("click", () => fileInput.click());
  dropzone.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fileInput.click(); } });
  fileInput.addEventListener("change", () => { if (fileInput.files[0]) handleFile(fileInput.files[0]); });
  ["dragenter", "dragover"].forEach((ev) => dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((ev) => dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.remove("drag"); }));
  dropzone.addEventListener("drop", (e) => { const f = e.dataTransfer.files[0]; if (f) handleFile(f); });

  $("#removeFile").addEventListener("click", () => {
    resetFileUI();
    if (state.fromFile) { notes.value = ""; state.fromFile = false; updateCount(); }
    toast("File removed.", "info");
  });
  $("#sampleBtn").addEventListener("click", () => {
    resetFileUI(); state.fromFile = false;
    notes.value = SAMPLE_TEXT; updateCount();
    toast("Sample document loaded.", "success");
  });
  $("#clearBtn").addEventListener("click", () => {
    resetFileUI(); state.fromFile = false;
    notes.value = ""; updateCount(); notes.focus();
  });

  /* ---------- 5. Summary ---------- */
  const panels = { empty: $("#emptyState"), processing: $("#processing"), error: $("#errorBox"), result: $("#summaryResult") };
  function showPanel(name) { Object.entries(panels).forEach(([k, el]) => { el.hidden = k !== name; }); }

  const STATUS_MESSAGES = ["Reading your notes…", "Identifying key concepts…", "Extracting definitions…", "Structuring the summary…", "Preparing your summary…"];
  let statusTimer = null;
  function startStatus() {
    let i = 0;
    $("#statusText").textContent = STATUS_MESSAGES[0];
    statusTimer = setInterval(() => { i = Math.min(i + 1, STATUS_MESSAGES.length - 1); $("#statusText").textContent = STATUS_MESSAGES[i]; }, 2200);
  }
  function stopStatus() { clearInterval(statusTimer); statusTimer = null; }

  function showError(message) {
    $("#errorText").textContent = message;
    showPanel("error");
    icons();
    toast(message, "error");
  }

  function setSummaryBusy(busy) {
    const btn = $("#generateBtn");
    btn.disabled = busy;
    btn.classList.toggle("loading", busy);
    btn.querySelector(".btn-label").textContent = busy ? "Generating…" : "✦ Generate Smart Summary";
    $("#regenBtn").disabled = busy;
  }

  async function generateSummary() {
    if (locks.has("summary")) return;
    const problem = validateNotes();
    if (problem) { showError(problem); notes.focus(); return; }

    locks.add("summary");
    setSummaryBusy(true);
    showPanel("processing");
    startStatus();
    if (window.innerWidth < 1020) $("#resultsPanel").scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });

    try {
      const data = await postJSON("/api/summarize", {
        text: notesText(), length: getOption("length"), language: getOption("language"),
        style: getOption("style"), demo: useDemo(),
      });
      state.summary = data;
      renderSummary(data);
      showPanel("result");
      icons();
    } catch (e) {
      showError(e.message);
    } finally {
      stopStatus();
      locks.delete("summary");
      setSummaryBusy(false);
    }
  }

  // Wrap keywords in <mark>. One regex pass so we never match inside our own tags.
  function highlight(text, keywords) {
    const safe = esc(text);
    const list = (keywords || []).map((k) => esc(k)).filter(Boolean)
      .sort((a, b) => b.length - a.length)
      .map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    if (!list.length) return safe;
    try {
      const re = new RegExp(`(?<![\\p{L}\\p{N}\\p{M}])(${list.join("|")})(?![\\p{L}\\p{N}\\p{M}])`, "giu");
      return safe.replace(re, '<mark class="kw">$1</mark>');
    } catch (e) { return safe; }
  }

  const wordCount = (s) => (s.trim() ? s.trim().split(/\s+/).length : 0);

  function renderSummary(d) {
    const style = getOption("style");
    const kws = d.keywords || [];
    $("#sumTitle").textContent = d.title;
    $("#demoBadge").hidden = !d.demo;

    const words = wordCount(d.summary.join(" "));
    const lengthLabel = { short: "Short", medium: "Medium", detailed: "Detailed" }[getOption("length")];
    $("#sumMeta").textContent = `${words} words · ${d.demo ? "Sample" : lengthLabel} · ${getOption("language")}`;

    $("#sumBody").innerHTML = style === "paragraph"
      ? d.summary.map((p) => `<p>${highlight(p, kws)}</p>`).join("")
      : `<ul>${d.summary.map((p) => `<li>${highlight(p, kws)}</li>`).join("")}</ul>`;

    $("#conceptsList").innerHTML = (d.key_concepts || []).length
      ? d.key_concepts.map((c) => `<div class="concept"><strong>${esc(c.term)}</strong><span>${highlight(c.definition, kws)}</span></div>`).join("")
      : "<p>No key concepts returned.</p>";

    $("#takeawayList").innerHTML = (d.takeaways || []).map((t) => `<li><i data-lucide="check-circle-2"></i><span>${highlight(t, kws)}</span></li>`).join("");
    $("#keywordList").innerHTML = kws.length ? kws.map((k) => `<span class="chip">${esc(k)}</span>`).join("") : "<p>No keywords returned.</p>";
  }

  function summaryAsText() {
    const d = state.summary;
    if (!d) return "";
    const out = [d.title, "=".repeat(Math.min(d.title.length, 60)), "", "SUMMARY"];
    d.summary.forEach((s) => out.push(getOption("style") === "paragraph" ? s + "\n" : `- ${s}`));
    if (d.key_concepts.length) { out.push("", "KEY CONCEPTS"); d.key_concepts.forEach((c) => out.push(`* ${c.term}: ${c.definition}`)); }
    if (d.takeaways.length) { out.push("", "MAIN TAKEAWAYS"); d.takeaways.forEach((t, i) => out.push(`${i + 1}. ${t}`)); }
    if (d.keywords.length) out.push("", "KEYWORDS", d.keywords.join(", "));
    if (d.demo) out.push("", "(DEMO sample output - not generated from your notes)");
    out.push("", "Generated by NeuroNotes AI");
    return out.join("\n");
  }

  async function copySummary() {
    const text = summaryAsText();
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      toast("Summary copied to clipboard.", "success");
    } catch (e) {
      // Fallback for older browsers / insecure origins
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      let ok = false;
      try { ok = document.execCommand("copy"); } catch (err) { /* ignore */ }
      ta.remove();
      toast(ok ? "Summary copied to clipboard." : "Couldn't copy. Please select the text manually.", ok ? "success" : "error");
    }
  }

  function downloadSummary() {
    const text = summaryAsText();
    if (!text) return;
    const name = (state.summary.title || "summary").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "summary";
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url; a.download = `${name}.txt`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Summary downloaded.", "success");
  }

  $("#generateBtn").addEventListener("click", generateSummary);
  $("#regenBtn").addEventListener("click", generateSummary);
  $("#copyBtn").addEventListener("click", copySummary);
  $("#downloadBtn").addEventListener("click", downloadSummary);

  /* ---------- Tabs ---------- */
  const tabs = $$(".tab");
  function selectTab(tab, focus) {
    tabs.forEach((t) => {
      const on = t === tab;
      t.classList.toggle("active", on);
      t.setAttribute("aria-selected", String(on));
      t.tabIndex = on ? 0 : -1;
      $(`#panel-${t.dataset.tab}`).hidden = !on;
    });
    if (focus) tab.focus();
  }
  tabs.forEach((t, i) => {
    t.addEventListener("click", () => selectTab(t));
    t.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight") { e.preventDefault(); selectTab(tabs[(i + 1) % tabs.length], true); }
      if (e.key === "ArrowLeft") { e.preventDefault(); selectTab(tabs[(i - 1 + tabs.length) % tabs.length], true); }
    });
  });

  /* Generic runner for the three tools: validates, locks, shows loading/errors */
  async function runTool({ key, btn, loading, errorBox, url, extra, onDone }) {
    if (locks.has(key)) return;
    const err = $(errorBox);
    err.hidden = true;
    const problem = validateNotes();
    if (problem) { $("p", err).textContent = problem; err.hidden = false; icons(); toast(problem, "error"); return; }
    locks.add(key);
    btn.disabled = true;
    $(loading).hidden = false;
    try {
      const data = await postJSON(url, { text: notesText(), language: getOption("language"), demo: useDemo(), ...extra });
      onDone(data);
    } catch (e) {
      $("p", err).textContent = e.message; err.hidden = false; icons();
      toast(e.message, "error");
    } finally {
      $(loading).hidden = true;
      btn.disabled = false;
      locks.delete(key);
    }
  }

  /* ---------- 6. MCQs ---------- */
  $("#mcqGenBtn").addEventListener("click", () => runTool({
    key: "mcq", btn: $("#mcqGenBtn"), loading: "#mcqLoading", errorBox: "#mcqError",
    url: "/api/mcqs", extra: { count: Number($("#mcqCount").value) },
    onDone: (data) => {
      state.mcqs = data.questions;
      $("#mcqDemo").hidden = !data.demo;
      $("#mcqEmpty").hidden = true;
      renderMcqs();
    },
  }));

  function renderMcqs() {
    state.mcqAnswered = 0; state.mcqScore = 0;
    $("#mcqFinal").hidden = true;
    $("#mcqWrap").hidden = false;
    $("#mcqList").innerHTML = state.mcqs.map((q, qi) => `
      <fieldset class="mcq" data-q="${qi}" style="border:1px solid var(--border);margin:0;min-width:0">
        <legend class="sr-only">Question ${qi + 1}</legend>
        <h4><small>Q${qi + 1}.</small>${esc(q.question)}</h4>
        <div class="opts">
          ${q.options.map((o, oi) => `<button type="button" class="opt" data-o="${oi}"><span class="letter">${"ABCD"[oi]}</span><span>${esc(o)}</span></button>`).join("")}
        </div>
        <div class="explain" hidden></div>
      </fieldset>`).join("");
    updateMcqScore();
  }

  function updateMcqScore() {
    $("#mcqScore").textContent = `Answered ${state.mcqAnswered} / ${state.mcqs.length} · Score ${state.mcqScore}`;
  }

  $("#mcqList").addEventListener("click", (e) => {
    const opt = e.target.closest(".opt");
    if (!opt || opt.disabled) return;
    const box = opt.closest(".mcq");
    const q = state.mcqs[Number(box.dataset.q)];
    const chosen = Number(opt.dataset.o);
    const buttons = $$(".opt", box);
    buttons.forEach((b, i) => {
      b.disabled = true;
      if (i === q.answer_index) b.classList.add("correct");
      else if (i === chosen) b.classList.add("wrong");
    });
    const right = chosen === q.answer_index;
    const exp = $(".explain", box);
    exp.innerHTML = `<strong>${right ? "Correct!" : `Not quite — the answer is ${"ABCD"[q.answer_index]}.`}</strong> ${esc(q.explanation || "")}`;
    exp.hidden = false;
    state.mcqAnswered += 1;
    if (right) state.mcqScore += 1;
    updateMcqScore();

    if (state.mcqAnswered === state.mcqs.length) {
      const pct = Math.round((state.mcqScore / state.mcqs.length) * 100);
      const msg = pct >= 80 ? "Excellent work!" : pct >= 50 ? "Good effort — review the explanations and try again." : "Keep practising — re-read your summary and retry.";
      const fin = $("#mcqFinal");
      fin.innerHTML = `<div class="big">${state.mcqScore} / ${state.mcqs.length}</div><p>${pct}% · ${msg}</p><button type="button" class="btn btn-ghost btn-sm" id="retakeBtn"><i data-lucide="refresh-cw"></i> Retake quiz</button>`;
      fin.hidden = false;
      icons();
      $("#retakeBtn").addEventListener("click", renderMcqs);
      fin.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "nearest" });
    }
  });

  /* ---------- 7. Flashcards ---------- */
  $("#cardsGenBtn").addEventListener("click", () => runTool({
    key: "cards", btn: $("#cardsGenBtn"), loading: "#cardsLoading", errorBox: "#cardsError",
    url: "/api/flashcards", extra: { count: 8 },
    onDone: (data) => {
      state.cards = data.cards; state.cardIdx = 0;
      $("#cardsDemo").hidden = !data.demo;
      $("#cardsEmpty").hidden = true;
      $("#cardsStage").hidden = false;
      showCard();
    },
  }));

  function showCard() {
    const card = state.cards[state.cardIdx];
    $("#flashcard").classList.remove("flipped");
    $("#flashcard").setAttribute("aria-label", "Flashcard. Press to flip.");
    $("#cardFront").textContent = card.front;
    $("#cardBack").textContent = card.back;
    $("#cardPos").textContent = `Card ${state.cardIdx + 1} of ${state.cards.length}`;
    $("#prevCard").disabled = state.cardIdx === 0;
    $("#nextCard").disabled = state.cardIdx === state.cards.length - 1;
  }
  function moveCard(step) {
    const next = state.cardIdx + step;
    if (next < 0 || next >= state.cards.length) return;
    state.cardIdx = next; showCard();
  }
  $("#flashcard").addEventListener("click", (e) => {
    const c = e.currentTarget;
    c.classList.toggle("flipped");
    c.setAttribute("aria-label", c.classList.contains("flipped") ? "Showing answer. Press to flip back." : "Showing question. Press to flip.");
  });
  $("#prevCard").addEventListener("click", () => moveCard(-1));
  $("#nextCard").addEventListener("click", () => moveCard(1));
  $("#cardsStage").addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") moveCard(-1);
    if (e.key === "ArrowRight") moveCard(1);
  });

  /* ---------- 8. Ask your notes (chat) ---------- */
  const chatLog = $("#chatLog");
  function addMessage(role, text, opts = {}) {
    const el = document.createElement("div");
    el.className = `msg ${role}${opts.error ? " error" : ""}`;
    const avatar = role === "ai" ? '<i data-lucide="brain-circuit"></i>' : '<i data-lucide="user"></i>';
    const badge = opts.unsupported ? '<span class="unsupported"><i data-lucide="alert-triangle"></i> Not found in your notes</span><br>' : "";
    el.innerHTML = `<div class="avatar">${avatar}</div><div class="bubble">${badge}${esc(text)}</div>`;
    chatLog.appendChild(el);
    icons();
    chatLog.scrollTop = chatLog.scrollHeight;
    return el;
  }
  function addTyping() {
    const el = document.createElement("div");
    el.className = "msg ai";
    el.innerHTML = '<div class="avatar"><i data-lucide="brain-circuit"></i></div><div class="bubble"><span class="typing" aria-label="AI is typing"><i></i><i></i><i></i></span></div>';
    chatLog.appendChild(el); icons();
    chatLog.scrollTop = chatLog.scrollHeight;
    return el;
  }

  $("#chatForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (locks.has("chat")) return;
    const input = $("#chatInput");
    const question = input.value.trim();
    if (!question) return;

    const problem = validateNotes();
    if (problem) { addMessage("ai", problem, { error: true }); toast(problem, "error"); return; }

    locks.add("chat");
    $("#chatSend").disabled = true;
    addMessage("user", question);
    input.value = "";
    const typing = addTyping();
    try {
      const data = await postJSON("/api/ask", {
        text: notesText(), question, demo: useDemo(),
        history: state.chat.slice(-6),
      });
      typing.remove();
      addMessage("ai", (data.demo ? "[DEMO] " : "") + data.answer, { unsupported: data.supported === false && !data.demo });
      state.chat.push({ role: "user", text: question }, { role: "ai", text: data.answer });
    } catch (err) {
      typing.remove();
      addMessage("ai", err.message, { error: true });
      toast(err.message, "error");
    } finally {
      locks.delete("chat");
      $("#chatSend").disabled = false;
      input.focus();
    }
  });

  $("#clearChat").addEventListener("click", () => {
    state.chat = [];
    chatLog.innerHTML = "";
    addMessage("ai", "Chat cleared. Ask me anything about your notes.");
  });

  /* ---------- Init ---------- */
  icons();
  updateCount();
  loadStatus();
})();
